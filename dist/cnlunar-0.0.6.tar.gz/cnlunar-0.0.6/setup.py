from setuptools import setup
setup(
    name='cnlunar',
    version='0.0.6',
    packages=['cnlunar'],
    url='https://github.com/OPN48/pyLunarCalendar',
    author='cuba3',
    author_email='cuba3@163.com',
)
